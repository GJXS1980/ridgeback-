# MoveIt! Plugins

This is a collection of plugins for MoveIt:
 - moveit_simple_controller_manager - A very basic controller manager plugin. Can connect to FollowJointTrajectoryAction and GripperCommandAction servers.
