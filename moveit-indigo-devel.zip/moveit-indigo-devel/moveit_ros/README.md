#MoveIt! ROS

This repository includes components of MoveIt that use ROS. This is where much of the functionality MoveIt provides it put together. Libraries from MoveIt Core and various plugins are used to provide that functionality.
- planning
- planning interfaces
- benchmarking
- manipulation
- visualization
