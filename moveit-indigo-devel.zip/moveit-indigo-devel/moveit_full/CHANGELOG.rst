^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package moveit_full
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.12 (2017-08-06)
-------------------

0.7.11 (2017-06-21)
-------------------

0.7.10 (2017-06-07)
-------------------

0.7.9 (2017-04-03)
------------------

0.7.8 (2017-03-08)
------------------

0.7.7 (2017-02-06)
------------------
* [Indigo] Move metapackages from moveit_metapackage repo.
* Contributors: Isaac I.Y. Saito

0.7.6 (2017-01-05)
------------------
* [improve] Delegate moveit_full to moveit metapackage. (`#8 <https://github.com/ros-planning/moveit_metapackages/issues/8>`_)
* Contributors: Isaac I.Y. Saito

0.6.2 (2016-06-24)
------------------
* [fix] changelog sorted in chronological order.
* Contributors: Isaac I.Y. Saito

0.6.1 (2015-01-16)
------------------
* add maintainer so I catch build failures
* Contributors: Michael Ferguson

0.6.0 (2015-01-14)
------------------

0.5.0 (2013-07-30)
------------------
* add changelogs

0.4.2 (2013-07-03)
------------------

0.4.1 (2013-06-07)
------------------
* add dep on moveit_plugins

0.4.0 (2013-05-23)
------------------

0.3.3 (2013-05-02)
------------------

0.3.2 (2013-04-16)
------------------
* ad buildtool depends
* add cmake lists files

0.3.1 (2013-02-04)
------------------
* removing build deps

0.3.0 (2012-12-28)
------------------
* fix buildtool tag

0.1.1 (2012-11-26)
------------------
* added new package for deps

0.1.0 (2012-11-19)
------------------
* add meta-packages
