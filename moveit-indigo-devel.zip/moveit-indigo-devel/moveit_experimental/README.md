# Experimental Packages for MoveIt!

This repository includes possibly broken/unmaintained/unfinished libraries that are being worked on or have been worked on in the past. They are not part of MoveIt! officially.

No support is offered for code in this repository, but you are welcome to use it if you see fit.
