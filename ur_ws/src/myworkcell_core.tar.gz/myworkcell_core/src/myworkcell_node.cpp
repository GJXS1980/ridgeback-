#include <ros/ros.h>
#include <myworkcell_core/LocalizePart.h>
#include <tf/tf.h>
#include <moveit/move_group_interface/move_group.h>


int main(int argc, char **argv)
{
  ros::init(argc, argv, "move_group_interface_tutorial");

  ros::NodeHandle node_handle;

  ros::AsyncSpinner spinner(1);

  spinner.start();



  moveit::planning_interface::MoveGroup group("manipulator");



  // 设置机器人终端的目标位置

  geometry_msgs::Pose target_pose1;

  target_pose1.orientation.w = 0.726282;

  target_pose1.orientation.x= 4.04423e-07;

  target_pose1.orientation.y = -0.687396;

  target_pose1.orientation.z = 4.81813e-07;



  target_pose1.position.x = 0.0261186;

  target_pose1.position.y = 4.50972e-07;

  target_pose1.position.z = 0.573659;

  group.setPoseTarget(target_pose1);





  // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动

  moveit::planning_interface::MoveGroup::Plan my_plan;







  //让机械臂按照规划的轨迹开始运动。

  group.execute(my_plan);



  ros::shutdown();

  return 0;
}
